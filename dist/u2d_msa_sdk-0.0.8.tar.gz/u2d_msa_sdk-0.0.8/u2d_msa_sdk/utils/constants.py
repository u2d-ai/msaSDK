ERROR = "SPK_V1_ERROR"
ERROR_NO_TEXT = "{\"" + ERROR + "\": \"" + "InputText empty" + "\"}"

ERROR_NO_FILE = "{\"" + ERROR + "\": \"" + "No File provided" + "\"}"
ERROR_NO_FILES = "{\"" + ERROR + "\": \"" + "No File provided" + "\"}"
ERROR_NO_UID = "{\"" + ERROR + "\": \"" + "No UID provided" + "\"}"
